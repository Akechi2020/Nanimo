package com.infosys.exception;

public class BusinessException extends Exception {
	
	private static final long serialVersionUID = -1649612722565666517L;
	
	public BusinessException(final String message) {
		super(message);
	}
}