package com.infosys.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.infosys.pojo.Ship;

public final class ShipList implements Serializable {
	
	private static final long serialVersionUID = 33331556790424360L;
	
	private List<Ship> shipList;
	
	private static ShipList instance;
	
	private ShipList() {
		final int initialCapacity = 3;
		shipList = new ArrayList<Ship>(initialCapacity);
		final Ship ship1 = new Ship();
		ship1.setShipNo("Ship No. 1");
		ship1.setCapacity(40);
		ship1.setGoodsLoaded(0);
		ship1.setFreeDeadWeight(40);
		shipList.add(ship1);
		final Ship ship2 = new Ship();
		ship2.setShipNo("Ship No. 2");
		ship2.setCapacity(60);
		ship2.setGoodsLoaded(0);
		ship2.setFreeDeadWeight(60);
		shipList.add(ship2);
		final Ship ship3 = new Ship();
		ship3.setShipNo("Ship No. 3");
		ship3.setCapacity(100);
		ship3.setGoodsLoaded(0);
		ship3.setFreeDeadWeight(100);
		shipList.add(ship3);
	}
	
	public synchronized static ShipList getInstance() {
		if (null == instance) {
			instance = new ShipList();
		}
		return instance;
	}
	
	public List<Ship> getShipList() {
		return shipList;
	}
}