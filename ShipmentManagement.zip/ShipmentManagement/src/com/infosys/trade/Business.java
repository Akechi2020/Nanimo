package com.infosys.trade;

import com.infosys.exception.BusinessException;
import com.infosys.pojo.Order;

public interface Business {
	
	Order takeOrder(final int orderQuantity) throws BusinessException;
}