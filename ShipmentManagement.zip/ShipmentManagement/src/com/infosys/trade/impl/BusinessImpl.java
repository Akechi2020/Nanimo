package com.infosys.trade.impl;

import java.util.ArrayList;
import java.util.List;

import com.infosys.exception.BusinessException;
import com.infosys.model.ShipList;
import com.infosys.pojo.Order;
import com.infosys.pojo.OrderDetails;
import com.infosys.pojo.Ship;
import com.infosys.trade.Business;

public class BusinessImpl implements Business {
	
	@Override
	public Order takeOrder(final int orderQuantity) throws BusinessException {
		Order order = null;
		if (orderQuantity > 0) {
			final ShipList instance = ShipList.getInstance();
			final List<Ship> shipList = instance.getShipList();
			order = new Order();
			final long orderNo = System.currentTimeMillis();
			order.setOrderNo(orderNo);
			order.setOrderQuantity(orderQuantity);
			int balance = orderQuantity;
			final List<Ship> orderShips = new ArrayList<Ship>();
			for (final Ship ship : shipList) {
				final int capacity = ship.getCapacity();
				balance -= capacity;
				if (balance < 0) {
					final int freeDeadWeight = -balance;
					final int goodsLoaded = capacity - freeDeadWeight;
					ship.setGoodsLoaded(goodsLoaded);
					ship.setFreeDeadWeight(freeDeadWeight);
					orderShips.add(ship);
					break;
				} else if (balance == 0) {
					ship.setGoodsLoaded(capacity);
					ship.setFreeDeadWeight(0);
					orderShips.add(ship);
					break;
				} else {
					ship.setGoodsLoaded(capacity);
					ship.setFreeDeadWeight(0);
					orderShips.add(ship);
				}
			}
			if (balance > 0) {
				final String message = "Too many requests. Please less than 200.";
				throw new BusinessException(message);
			}
			final int size = orderShips.size();
			final Ship[] ships = new Ship[size];
			for (int i = 0; i < ships.length; i++) {
				ships[i] = orderShips.get(i);
			}
			final OrderDetails details = new OrderDetails();
			details.setOrderNo(orderNo);
			details.setShips(ships);
			order.setOrderDetail(details);
		}
		return order;
	}	
}