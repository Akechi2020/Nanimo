package com.infosys.pojo;

import java.io.Serializable;

public class OrderDetails implements Serializable {
	
	private static final long serialVersionUID = -4824012353170141432L;
	
	private long orderNo;
	
	private Ship[] ships;
	
	public long getOrderNo() {
		return orderNo;
	}
	
	public void setOrderNo(long orderNo) {
		this.orderNo = orderNo;
	}
	
	public Ship[] getShips() {
		return ships;
	}
	
	public void setShips(Ship[] ships) {
		this.ships = ships;
	}
}