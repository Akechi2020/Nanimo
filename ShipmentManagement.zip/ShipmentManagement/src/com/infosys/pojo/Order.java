package com.infosys.pojo;

import java.io.Serializable;

public class Order implements Serializable {
	
	private static final long serialVersionUID = 4831409721982328867L;
	
	private long orderNo;
	
	private int orderQuantity;
	
	private OrderDetails orderDetail;
	
	public long getOrderNo() {
		return orderNo;
	}
	
	public void setOrderNo(long orderNo) {
		this.orderNo = orderNo;
	}
	
	public int getOrderQuantity() {
		return orderQuantity;
	}
	
	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}
	
	public OrderDetails getOrderDetail() {
		return orderDetail;
	}
	
	public void setOrderDetail(OrderDetails orderDetail) {
		this.orderDetail = orderDetail;
	}
}