package com.infosys.pojo;

import java.io.Serializable;

public class Ship implements Serializable {
	
	private static final long serialVersionUID = 7162007277643377714L;
	
	private String shipNo;
	
	private int capacity;
	
	private int goodsLoaded;
	
	private int freeDeadWeight;
	
	public String getShipNo() {		
		return shipNo;
	}
	
	public void setShipNo(String shipNo) {
		this.shipNo = shipNo;
	}
	
	public int getCapacity() {
		return capacity;
	}
	
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	public int getGoodsLoaded() {
		return goodsLoaded;
	}
	
	public void setGoodsLoaded(int goodsLoaded) {
		this.goodsLoaded = goodsLoaded;
	}
	
	public int getFreeDeadWeight() {
		return freeDeadWeight;
	}
	
	public void setFreeDeadWeight(int freeDeadWeight) {
		this.freeDeadWeight = freeDeadWeight;
	}
}