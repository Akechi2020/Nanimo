package com.client;

import com.infosys.exception.BusinessException;
import com.infosys.pojo.Order;
import com.infosys.pojo.OrderDetails;
import com.infosys.pojo.Ship;
import com.infosys.trade.Business;
import com.infosys.trade.impl.BusinessImpl;

public class Client {
	
	public Order orede(final int orderNum) {
		final Business business = new BusinessImpl();
		Order order = null;
		try {
			order = business.takeOrder(orderNum);
		} catch (BusinessException e) {
			e.printStackTrace();
		}
		return order;
	}
	
	public static void main(String[] args) {
		final Client client = new Client();
		final Order order = client.orede(200);
		if (null == order) {
			System.out.println("No order be created.");
			return;
		}
		System.out.println("OrderNo is :" + order.getOrderNo() + "\tOrderQuantity is :" + order.getOrderQuantity());
		final OrderDetails orderDetail = order.getOrderDetail();
		System.out.println("OrderNo is :" + orderDetail.getOrderNo());
		final Ship[] ships = orderDetail.getShips();
		for (final Ship ship : ships) {
			System.out.println(ship.getShipNo() + "\tCapacity is :" + ship.getCapacity() + "\tGoodsLoaded is :"
					+ ship.getGoodsLoaded() + "\tFreeDeadWeight is :" + ship.getFreeDeadWeight());
		}
	}
}